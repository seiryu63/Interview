package myFinalProject;

import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

public class UtilsClass {

	public static WebDriver LoadDriver() {
		System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\webdrivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		String url = "https://www.saucedemo.com/";
		driver.get(url);
		return driver;
	}

	public static void Login(WebDriver driver) {
		String user = "standard_user";
		String password = "secret_sauce";

		WebElement inputUser = driver.findElement(By.name("user-name"));
		WebElement inputPass = driver.findElement(By.id("password"));

		inputUser.sendKeys(user);
		inputPass.sendKeys(password);

		/* Click on Sign In button */
		WebElement btnSubmit = driver.findElement(By.xpath("//input[@type='submit']"));
		btnSubmit.click();
	}
	
	
	
	
	
	

	public static void Logout(WebDriver driver) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 40);
		//driver.quit();
	}
	
	public static List<String> SortDesc(List<String> table) {
		table.sort(Collections.reverseOrder());
		return table;
	}

	public static List<String> SortAsc(List<String> table) {
		Collections.sort(table);
		return table;
	}
	
	public static boolean isElementPresent(WebDriver b ,By by) {
	
		
		try {
		  
		    b.findElements(by);
		    return false;
		  }
		catch (NoSuchElementException e) {
		    return true;
		  }
		}

}
