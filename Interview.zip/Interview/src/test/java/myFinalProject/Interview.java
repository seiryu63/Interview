package myFinalProject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Interview extends UtilsClass {
	
	WebDriver driver;
	
	@BeforeTest
	public void meth() {


		driver = UtilsClass.LoadDriver();
		UtilsClass.Login(driver);
		// }
	}
	
	@Test
	public void Sort() throws IOException{
	
		WebElement btnSort = driver.findElement(By.xpath("//select[@class='product_sort_container']//option[4]"));
		btnSort.click();
	
	}
	

}
